import React, { useEffect, useState } from 'react';
import './App.css';
import ActivityChart from './components/ActivityChart';
import { fetchData } from './api';

function App() {
    // Estados para almacenar todos los datos de Apple Watch y Fitbit
    const [awData, setAwData] = useState({ documents: [] });
    const [fitbitData, setFitbitData] = useState({ documents: [] });

    // Obtener datos de la API
    useEffect(() => {
        async function loadData() {
            const awData = await fetchData('http://127.0.0.1:8000/documents/health_data/aw_data');
            setAwData(awData);

            const fitbitData = await fetchData('http://127.0.0.1:8000/documents/health_data/fitbit_data');
            setFitbitData(fitbitData);
        }

        loadData();
    }, []);

    return (
        <div className="App">
            <h1>Datos de Salud - Comparaciones de Relojes Inteligentes</h1>
            <ActivityChart awData={awData} />
            {/* En el futuro puedes agregar más componentes para otras gráficas */}
        </div>
    );
}

export default App;
