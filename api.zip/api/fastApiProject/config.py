# config.py

connection_string = "mongodb+srv://pabloohuertass:korrpa56@cluster0.m2rzk8b.mongodb.net/ssl=true&tlsAllowInvalidCertificates=true"
